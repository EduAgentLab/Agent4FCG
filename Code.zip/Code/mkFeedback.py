import json
import os
import time
import requests
from datetime import datetime

API_KEY = "Your_API_KEY" 
BASE_ROOT_DIR = "Output_Directory"

DIMENSIONS_CONFIG = {
    "Q1": "how would you evaluate the author’s selection of source materials in terms of relevance, quality, and quantity of the materials? Note: \"If the draft has a noticeable issue regarding the number or the quality of the papers reviewed, please comment on the issue.",
    "Q2": "how would you evaluate the writing for its integration of source materials (e.g., clarity of presenting information) and citation practices (e.g., use of APA or other style in both in-text citations and reference list)?",
    "Q3": "how would you evaluate the writing for the quality or effectiveness of each component (i.e., Introduction, Body, and Conclusions)? Note: The introduction is expected to introduce a research area, identify issue(s), and/or state the significance of the issue(s). The body of liteature review should present the relevant ideas or findings of the reviewed studies and/or identify a research gap. The conclusion(s) may identify research trends or controversies and highlight the contribution of this literature review.",
    "Q4": "how would you evaluate the logical structure of this liteature review?",
    "Q5": "how would you evaluate the content and clarity of ideas expressed in this liteature review?",
    "Q6": "how would you evaluate the liteature review for the quality of coherence (e.g., the connectivity and the naturalness of the flow of ideas in this draft)?",
    "Q7": "how would you evaluate the liteature review for the use of connectors (e.g., ‘because,’ ‘therefore,’ ‘however,’ ‘likewise’, and ‘similarly’) to link sentences in this draft?",
    "Q8": "how would you evaluate the draft for grammatical accuracy, sentence length and sentence type variety?",
    "Q9": "how would you evaluate the draft for vocabulary quality (e.g., use of academic expressions, the correctness of word choice, the naturalness of collocations, the complexity of vocabulary, the use of stylistically acceptable vocabulary—not too colloquial, not excessively formal or not overusing terms)?",
}

def call_dify_workflow(inputs, api_key, url, user_id, on_finish, timeout=120):
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json;charset=UTF-8"
    }
    payload = {
        "inputs": inputs,
        "response_mode": "streaming",
        "user": user_id
    }

    try:
        response = requests.post(url, headers=headers, json=payload, stream=True, timeout=timeout)
        if response.status_code != 200:
            raise Exception(f"HTTP {response.status_code}")

        final_outputs = {}
        for line in response.iter_lines():
            if not line: continue
            decoded_line = line.decode("utf-8").strip()
            if decoded_line.startswith("data:"): decoded_line = decoded_line[5:].strip()
            if not decoded_line or decoded_line == "[DONE]": continue

            try:
                event = json.loads(decoded_line)
                if event.get("event") == "workflow_finished":
                    final_outputs = event.get("data", {}).get("outputs", {})
                    break
            except: continue
        
        if final_outputs and callable(on_finish):
            on_finish(final_outputs)
        else:
            raise Exception("No output received")

    except Exception as e:
        print(f"API Fail: {e}")
        raise e

def handle_finish(outputs, target_dir, filename):
    os.makedirs(target_dir, exist_ok=True) 
    path = os.path.join(target_dir, filename)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(outputs, f, ensure_ascii=False, indent=2)
    print(f"Saved to: {path}")

def run_all_essays(data, progress_file, limit=0):
    if os.path.exists(progress_file):
        with open(progress_file, "r", encoding="utf-8") as f:
            done_ids = set(json.load(f))
    else:
        done_ids = set()

    remaining = [e for e in data if e["Essay"] not in done_ids]
    if limit > 0: remaining = remaining[:limit]

    for i, essay in enumerate(remaining, 1):
        essay_id = essay.get("Essay", "Unknown_ID")
        topic = essay.get("Topic", "")
        writing = essay.get("Writing", "")

        print("=" * 60)
        print(f"Target [{i}/{len(remaining)}]: {essay_id}")
        
        all_success = True

        for q_tag, dim_prompt in DIMENSIONS_CONFIG.items():
            folder_suffix = q_tag.replace("Q", "C") 
            folder_name = f"{folder_suffix}"
            current_dim_dir = os.path.join(BASE_ROOT_DIR, folder_name)
            current_filename = f"{essay_id}.json"

            if os.path.exists(os.path.join(current_dim_dir, current_filename)):
                print("Skipped (Exists)")
                continue

            try:
                call_dify_workflow(
                    inputs={
                        "topic": topic, 
                        "writing": writing, 
                        "Evaluation_dimension": dim_prompt
                    },
                    api_key=API_KEY,
                    url="Base_API_Endpoint_URL",
                    user_id=f"{essay_id}_{folder_suffix}",
                    on_finish=lambda o: handle_finish(o, current_dim_dir, current_filename)
                )
                time.sleep(1)
            except Exception:
                all_success = False
                break 

        if all_success:
            done_ids.add(essay_id)
            os.makedirs(os.path.dirname(progress_file), exist_ok=True)
            with open(progress_file, "w", encoding="utf-8") as f:
                json.dump(list(done_ids), f, ensure_ascii=False, indent=2)
        else:
            time.sleep(2)

if __name__ == "__main__":
    data_path = "Input_Data_File_Path.json"
    progress_path = "Progress_Tracking_File_Path.json"
    
    if os.path.exists(data_path):
        with open(data_path, "r", encoding="utf-8") as f:
            raw_data = json.load(f)
        run_all_essays(raw_data, progress_path, limit=0)#limit=0 means no limit
    else:
        print("Data file not found.")
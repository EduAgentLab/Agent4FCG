import os
import json
import time
import traceback
from datetime import datetime

import requests

API_KEY = "<API_KEY>"  # your app key
URL = "bAse_API_Endpoint_URL"
USER_ID = "your-IM-user-id"

MERGED_PATH = "Input_Data_File_Path.json"
OUTPUT_DIR = "workflow_outputs"
PROGRESS_FILE = "PROGRESS_Tracking_File_Path.json"
TIMEOUT = 120

def handle_event(event: dict):
    ev = event.get("event")
    if ev == "workflow_finished":
        data = event.get("data", {})
        print("=== workflow_finished ===")
        print("status:", data.get("status"))
        print("outputs:", json.dumps(data.get("outputs", {}), ensure_ascii=False, indent=2))


def handle_finish(outputs, base_dir="workflow_outputs", filename=None):
    os.makedirs(base_dir, exist_ok=True)

    if filename is None:
        topic = str(outputs.get("topic", "untitled")).strip().replace(" ", "_")[:40]
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{topic}_{timestamp}.json"

    path = os.path.join(base_dir, filename)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(outputs, f, ensure_ascii=False, indent=2)



def is_success_output(outputs: dict) -> bool:
    if not isinstance(outputs, dict):
        return False
    if outputs.get("_warn"):
        return False

    so = outputs.get("structured_output")
    if isinstance(so, dict) and len(so) > 0:
        return True
    if any(isinstance(k, str) and k.endswith("_Score") for k in outputs.keys()):
        return True

    return False


def call_dify_workflow(
    inputs: dict,
    api_key: str,
    url: str,
    user_id: str = "default-user",
    on_event=handle_event,
    on_finish=None,
    timeout: int = 120,
):

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json;charset=UTF-8",
        "Accept-Charset": "UTF-8",
    }

    payload = {
        "inputs": inputs,
        "response_mode": "streaming",
        "user": user_id,
    }

    last_node_outputs = None
    last_node_data = None
    last_workflow_finished_data = None

    try:
        response = requests.post(
            url, headers=headers, json=payload, stream=True, timeout=timeout
        )

        if response.status_code != 200:
            return None


        for raw in response.iter_lines():
            if not raw:
                continue

            decoded_line = raw.decode("utf-8", errors="replace").strip()
            if decoded_line.startswith("event:"):
                continue

            if decoded_line.startswith("data:"):
                decoded_line = decoded_line[5:].strip()

            if not decoded_line or decoded_line == "[DONE]":
                continue

            try:
                event = json.loads(decoded_line)
            except json.JSONDecodeError:
                continue

            if callable(on_event):
                on_event(event)

            ev = event.get("event")

            if ev == "node_finished":
                data = event.get("data", {}) or {}
                last_node_data = data
                cand = data.get("outputs")
                if cand:
                    last_node_outputs = cand

            if ev == "workflow_finished":
                data = event.get("data", {}) or {}
                last_workflow_finished_data = data

                outputs = data.get("outputs") or {}

                if not outputs:
                    outputs = {
                        "_warn": "Workflow finished.outputs is empty; attached workflow_finished.data and last node_finished outputs for debugging",
                        "_workflow_finished_data": last_workflow_finished_data,
                        "_last_node_outputs": last_node_outputs,
                        "_last_node_data": last_node_data,
                    }

                if callable(on_finish):
                    on_finish(outputs)

                return outputs
        return None

    except requests.exceptions.RequestException as e:
        return None


def run_all_essays(data, progress_file=PROGRESS_FILE):
    if os.path.exists(progress_file):
        try:
            with open(progress_file, "r", encoding="utf-8") as f:
                done_ids = set(json.load(f))
        except Exception:
            done_ids = set()
    else:
        done_ids = set()

    remaining = [e for e in data if e.get("Essay") not in done_ids]

    for essay in remaining:
        essay_id = essay.get("Essay", "Unknown_ID")
        topic = essay.get("Topic", "")
        writing = essay.get("Writing", "")

        try:
            outputs = call_dify_workflow(
                inputs={"topic": topic, "writing": writing},
                api_key=API_KEY,
                url=URL,
                user_id=USER_ID,
                on_event=handle_event,
                on_finish=None,  
                timeout=TIMEOUT,
            )

            if outputs is None:
                raise RuntimeError("No outputs received from workflow")

            if not is_success_output(outputs):
                raise RuntimeError("Output did not pass success criteria")

            handle_finish(outputs, base_dir=OUTPUT_DIR, filename=f"{essay_id}.json")

            done_ids.add(essay_id)
            with open(progress_file, "w", encoding="utf-8") as f:
                json.dump(sorted(list(done_ids)), f, ensure_ascii=False, indent=2)


        except Exception:
            traceback.print_exc()
            time.sleep(5)
            continue

if __name__ == "__main__":
    with open(MERGED_PATH, "r", encoding="utf-8") as f:
        data = json.load(f)

    run_all_essays(data)
